//
//  Message.swift
//  Messanger
//
//  Created by Hans M. Inderberg on 10/5/14.
//  Copyright (c) 2014 Hans M. Inderberg. All rights reserved.
//

import Foundation

public struct Message {
    
    public let id: String?
    public let date: NSDate?
    public let from: String?
    public let message: String?
    
    init(id: String, date: NSDate?, from: String, message: String) {
        self.id = id
        self.date = date
        self.from = from
        self.message = message
    }
    
    init(id: String, dateString: NSString, from: String, message: String) {
        var dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        var dateFromString = dateFormatter.dateFromString(dateString)
        
        if var date = dateFromString {
            self.init(id: id, date: date, from: from, message: message)
        } else {
            self.init(id: id, date: nil, from: from, message: message)
        }
        
    }
    
    
}
