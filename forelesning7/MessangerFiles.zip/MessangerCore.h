//
//  MessangerCore.h
//  MessangerCore
//
//  Created by Hans M. Inderberg on 10/5/14.
//  Copyright (c) 2014 Hans M. Inderberg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MessangerCore.
FOUNDATION_EXPORT double MessangerCoreVersionNumber;

//! Project version string for MessangerCore.
FOUNDATION_EXPORT const unsigned char MessangerCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MessangerCore/PublicHeader.h>


