//
//  MessangerService.swift
//  Messanger
//
//  Created by Hans M. Inderberg on 10/5/14.
//  Copyright (c) 2014 Hans M. Inderberg. All rights reserved.
//

import Foundation

extension qos_class_t {
    
    public var id:Int {
        return Int(self.value)
    }
}

public class MessangerService {
    
    let fetcher = Fetcher(url: NSURL(string: "http://mobile-course.herokuapp.com/message"))
    
    public init() {
        
    }
    
    public func getAllMessages(completionHandler: (messages:[Message]?, error: NSError?) -> ()) {
        
        let aQueue = dispatch_get_global_queue(QOS_CLASS_BACKGROUND.id, 0)

        dispatch_async(aQueue) {
            
            self.fetcher.GET() { (data, response, error) -> Void in
                if (error != nil) {
                    return completionHandler(messages: nil, error: error)
                }
                
                let messagesResult = self.convertMessages(data);
                
                if (messagesResult.error != nil) {
                    return completionHandler(messages: nil, error: messagesResult.error)
                }
                
                return completionHandler(messages:messagesResult.message , error: nil)
                
            }
            
        }
        
    }
    
    private func convertMessages(data: NSData) -> (message: [Message]?, error: NSError?){
        
        var messages: [Message]?
        
        var error: NSError?;
        
        if let arrayOfMessages = NSJSONSerialization.JSONObjectWithData(data, options: nil, error: &error) as? NSArray {
           
            messages = [Message]()
            
            for messageDictionary in arrayOfMessages {
                
                let id = messageDictionary["_id"] as String
                let date = messageDictionary["date"] as String
                let from = messageDictionary["from"] as String
                let message = messageDictionary["message"] as String
                
                var messageObject = Message(id: id, dateString: date, from: from, message: message)
                messages?.append(messageObject)
                
            }
            
        }
        
        return (message: messages, error: nil)
    }
}