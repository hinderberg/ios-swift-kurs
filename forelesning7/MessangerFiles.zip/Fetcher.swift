//
//  Fetcher.swift
//  Messanger
//
//  Created by Hans M. Inderberg on 10/5/14.
//  Copyright (c) 2014 Hans M. Inderberg. All rights reserved.
//

import Foundation

class Fetcher {
    
    let url: NSURL?
    
    init(url: NSURL) {
        self.url = url
    }
    
    func GET(completionHandler: (NSData!, NSURLResponse!, NSError!) -> Void) {
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithURL(self.url!, completionHandler)
        
        task.resume()
    }
    
    func GET(id: String, completionHandler: (NSData!, NSURLResponse!, NSError!) -> Void) {
        let session = NSURLSession.sharedSession()
        
        var url = NSURL(string: "\(self.url?.absoluteString)\(id)")
        
        let task = session.dataTaskWithURL(url, completionHandler)
        
        task.resume()
    }
    
    func PUT(data: NSData, completionHandler: (NSData!, NSURLResponse!, NSError!) -> Void) {
        
    }
    
    func POST(data: NSData, completionHandler: (NSData!, NSURLResponse!, NSError!) -> Void) {
        
    }
    
    func DELETE(id: String, completionHandler: (NSData!, NSURLResponse!, NSError!) -> Void) {
        
    }
}